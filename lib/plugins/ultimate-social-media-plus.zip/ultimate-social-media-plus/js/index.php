<?php
echo _('Access Denied');
?>
